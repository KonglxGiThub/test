package com.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.dao.THuifuDAO;
import com.dao.TUserDAO;
import com.dao.TZhutiDAO;
import com.model.THuifu;
import com.model.TZhuti;
import com.opensymphony.xwork2.ActionSupport;

public class zhutiAction extends ActionSupport
{
	private TZhutiDAO zhutiDAO;
	private THuifuDAO huifuDAO;
	private TUserDAO userDAO;
	
	private String message;
	private String path;
	
	public String zhutiAdd()
	{
		HttpServletRequest req=ServletActionContext.getRequest();
		
		String title=req.getParameter("title");
		String content=req.getParameter("content");
		String shijian=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date());
		String user_id=req.getParameter("user_id");
		String del="no";
		
		TZhuti zhuti=new TZhuti();
		zhuti.setTitle(title);
		zhuti.setContent(content);
		zhuti.setShijian(shijian);
		zhuti.setUser_id(Integer.parseInt(user_id));
		zhuti.setDel(del);
		
		zhutiDAO.save(zhuti);
		
		this.setMessage("�����ɹ�");
		this.setPath("zhutiAll.action");
	
		return "succeed";
	}
	
	
	public String zhutiAll()
	{
		HttpServletRequest req=ServletActionContext.getRequest();
		
		String sql="from TZhuti where del='no' order by id desc";
		List zhutiList=zhutiDAO.getHibernateTemplate().find(sql);
		for(int i=0;i<zhutiList.size();i++)
		{
			TZhuti zhuti=(TZhuti)zhutiList.get(i);
			zhuti.setUser(userDAO.findById(zhuti.getUser_id()));
			zhuti.setHuifushu(getHuifushu(zhuti.getId()));
		}
		
		req.setAttribute("zhutiList", zhutiList);
		return ActionSupport.SUCCESS;
	}
	
	
	public String zhutiDetail()
	{
		HttpServletRequest req=ServletActionContext.getRequest();
		int id=Integer.parseInt(req.getParameter("id"));
		
		TZhuti zhuti=zhutiDAO.findById(id);
		zhuti.setUser(userDAO.findById(zhuti.getUser_id()));
		zhuti.setHuifuList(getHuifuList(zhuti.getId()));
		
		req.setAttribute("zhuti", zhuti);
		return ActionSupport.SUCCESS;
	}
	
	
	
	public String zhutiMana()
	{
        HttpServletRequest req=ServletActionContext.getRequest();
		
		String sql="from TZhuti where del='no' order by id desc";
		List zhutiList=zhutiDAO.getHibernateTemplate().find(sql);
		for(int i=0;i<zhutiList.size();i++)
		{
			TZhuti zhuti=(TZhuti)zhutiList.get(i);
			zhuti.setUser(userDAO.findById(zhuti.getUser_id()));
			zhuti.setHuifushu(getHuifushu(zhuti.getId()));
		}
		
		req.setAttribute("zhutiList", zhutiList);
		return ActionSupport.SUCCESS;
	}
	
	
	public String zhutiDel()
	{
		HttpServletRequest req=ServletActionContext.getRequest();
		String id=req.getParameter("id");
		
		String sql="update TZhuti set del='yes' where id="+Integer.parseInt(id);
		zhutiDAO.getHibernateTemplate().bulkUpdate(sql);
		
		req.setAttribute("msg", "�����ɹ�");
		return "msg";
	}
	
	
	
	public String huifuAdd()
	{
		HttpServletRequest req=ServletActionContext.getRequest();
		
		String title=req.getParameter("title");
		String content=req.getParameter("content");
		String shijian=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date());
		String user_id=req.getParameter("user_id");
		
		String zhuti_id=req.getParameter("zhuti_id");
		String del="no";
		
		THuifu huifu=new THuifu();
		huifu.setTitle(title);
		huifu.setContent(content);
		huifu.setShijian(shijian);
		huifu.setUser_id(Integer.parseInt(user_id));
		huifu.setZhuti_id(Integer.parseInt(zhuti_id));
		huifu.setDel(del);
		
		
		huifuDAO.save(huifu);
		this.setMessage("�����ɹ�");
		this.setPath("zhutiAll.action");
	
		return "succeed";
	}
	
	
	public String huifuMana()
	{
		HttpServletRequest req=ServletActionContext.getRequest();
		
		int zhuti_id=Integer.parseInt(req.getParameter("zhuti_id"));
		req.setAttribute("huifuList", getHuifuList(zhuti_id));
		return ActionSupport.SUCCESS;
	}
	
	
	public String huifuDel()
	{
		HttpServletRequest req=ServletActionContext.getRequest();
		String id=req.getParameter("id");
		
		String sql="update THuifu set del='yes' where id="+Integer.parseInt(id);
		huifuDAO.getHibernateTemplate().bulkUpdate(sql);
		
		req.setAttribute("msg", "�����ɹ�");
		return "msg";
	}

	public THuifuDAO getHuifuDAO()
	{
		return huifuDAO;
	}


	public void setHuifuDAO(THuifuDAO huifuDAO)
	{
		this.huifuDAO = huifuDAO;
	}


	public TUserDAO getUserDAO()
	{
		return userDAO;
	}


	public void setUserDAO(TUserDAO userDAO)
	{
		this.userDAO = userDAO;
	}


	public TZhutiDAO getZhutiDAO()
	{
		return zhutiDAO;
	}


	public String getMessage()
	{
		return message;
	}


	public void setMessage(String message)
	{
		this.message = message;
	}


	public String getPath()
	{
		return path;
	}


	public void setPath(String path)
	{
		this.path = path;
	}


	public void setZhutiDAO(TZhutiDAO zhutiDAO)
	{
		this.zhutiDAO = zhutiDAO;
	}
	
	
	public int getHuifushu(int zhuti_id)
	{
		String sql="from THuifu where del='no' and zhuti_id="+zhuti_id;
		List list=huifuDAO.getHibernateTemplate().find(sql);
		
		return list.size();
	}
	
	public List getHuifuList(int zhuti_id)
	{
		String sql="from THuifu where del='no' and zhuti_id="+zhuti_id;
		List list=huifuDAO.getHibernateTemplate().find(sql);
		for(int i=0;i<list.size();i++)
		{
			THuifu huifu=(THuifu)list.get(i);
			huifu.setUser(userDAO.findById(huifu.getUser_id()));
		}
		
		return list;
	}
}
