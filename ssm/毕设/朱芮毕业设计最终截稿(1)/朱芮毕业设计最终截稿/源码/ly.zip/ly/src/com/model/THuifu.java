package com.model;

public class THuifu
{
	private int id;
	private String title;
	private String content;
	private String shijian;
	
	private int user_id;
	private int zhuti_id;
	private String del;
	private TUser user;
	
	
	public String getContent()
	{
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
	
	public int getZhuti_id()
	{
		return zhuti_id;
	}
	public void setZhuti_id(int zhuti_id)
	{
		this.zhuti_id = zhuti_id;
	}
	public String getDel()
	{
		return del;
	}
	
	public int getUser_id()
	{
		return user_id;
	}
	public void setUser_id(int user_id)
	{
		this.user_id = user_id;
	}
	public void setDel(String del)
	{
		this.del = del;
	}
	public int getId()
	{
		return id;
	}
	
	public void setId(int id)
	{
		this.id = id;
	}
	public String getShijian()
	{
		return shijian;
	}
	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}
	
	public TUser getUser()
	{
		return user;
	}
	public void setUser(TUser user)
	{
		this.user = user;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}

}
