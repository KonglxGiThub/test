package com.model;

import java.util.List;

public class TZhuti
{
	private int id;
	private String title;
	private String content;
	private String shijian;
	
	private int user_id;
	private String del;
	
	private TUser user;
	private List huifuList;
	private int huifushu;
	
	
	public String getContent()
	{
		return content;
	}
	public void setContent(String content)
	{
		this.content = content;
	}
	public String getDel()
	{
		return del;
	}
	public void setDel(String del)
	{
		this.del = del;
	}
	public List getHuifuList()
	{
		return huifuList;
	}
	public void setHuifuList(List huifuList)
	{
		this.huifuList = huifuList;
	}
	public int getHuifushu()
	{
		return huifushu;
	}
	public void setHuifushu(int huifushu)
	{
		this.huifushu = huifushu;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getShijian()
	{
		return shijian;
	}
	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
	public TUser getUser()
	{
		return user;
	}
	public void setUser(TUser user)
	{
		this.user = user;
	}
	public int getUser_id()
	{
		return user_id;
	}
	public void setUser_id(int user_id)
	{
		this.user_id = user_id;
	}
	
}
